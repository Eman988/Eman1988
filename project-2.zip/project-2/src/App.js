  import './App.css';
  //import rectangle from './images/rectangle.jpg';
  
  import SocialFollow from "./SocialFollow";
  import CardHeader from './CardHeader';
  import CardImage from './CardImage';
  
  

  function App() {
    return (
      <div className="main-container">
            <div className="card-1">
              <CardImage />
              
              <CardHeader/>
              
              <SocialFollow />
              
            </div>
      </div>      
    );
  }

  export default App;
