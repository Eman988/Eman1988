import React from "react";


export default function CardHeader() {
    return (
      
        <div className="card-header">
                    <h3 className="my-name">Eman Sawalha</h3>
                    <h4 className="job-title">Frontend Developer</h4>
                    <h5 className="personal-website">www.sawalha.com</h5>
                    <div className="main-buttons">
                        <button type="button" id="mail-button"><i class="fa fa-envelope"></i> Email</button>
                        <button type="button" id="linkedin-button"><i class="fa fa-linkedin-square"></i>LinkedIn</button>
                    </div>
                        <h2 className="about">About</h2>
                        <p className="about-paragraph">I am a frontend developer with a particular interest in 
                          making things simple and automating daily tasks. I try to
                          keep up with security and best practices, and am always
                          looking for new things to learn.</p>
                        <h2 className="interests">Interest</h2>
                        <p className="interest-paragraph">Food expert. Music scholar. Reader. Internet fanatic. 
                          Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. 
                          Coffee fanatic.
                        </p>
                  </div>
              
      
    );
  }