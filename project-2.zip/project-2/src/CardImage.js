import React from "react";
import Rectangle90 from './images/Rectangle90.png';

export default function CardImage() {
    return (
        <div className="my-pic">
                    <img classNeme="rectangle-pic"src={Rectangle90} alt="Eman-sawalha"/>
              </div>
    );

}