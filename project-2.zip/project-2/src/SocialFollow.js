import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faYoutube,
    faFacebook,
    faTwitter,
    faInstagram,
    faGithub
  } from "@fortawesome/free-brands-svg-icons";

export default function SocialFollow() {
  return (
    <div className="footer">
        <div class="social-container">
        <a href="https://www.twitter.com/EmanSawalha7" className="twitter social">
            <FontAwesomeIcon icon={faTwitter} />
        </a>
        
        <a href="https://www.facebook.com/Omari.Eman/"
            className="facebook social">
            <FontAwesomeIcon icon={faFacebook} />
        </a>
        <a href="https://www.instagram.com/eman.sawalhaa/"
            className="instagram social">
            <FontAwesomeIcon icon={faInstagram}  /> 
            </a>
            <a href="https://https://github.com/Eman988/Eman1988" className="github social">
            <FontAwesomeIcon icon={faGithub} />
        </a>
        
    </div>
    </div>
    
  );
}